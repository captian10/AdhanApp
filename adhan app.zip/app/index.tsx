import { Ionicons } from "@expo/vector-icons";
import { useAudioPlayer } from 'expo-audio';
import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useState } from "react";
import {
  Dimensions,
  FlatList,
  ImageBackground,
  Modal,
  RefreshControl,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import NextPrayerCountdown from "../components/NextPrayerCountdown";
import { AZAN_SOUNDS, getSoundPreference, saveSoundPreference, type AzanSound } from "../utils/audioSettings";
import { checkAndroidBackgroundRestrictions } from "../utils/autostart";
import { EGYPT_CITIES, type City } from "../utils/egyptLocations";
import {
  refreshPrayerSchedule,
  saveLocationPreference,
  scheduleTestAzan,
  type PrayerItem,
} from "../utils/scheduler";

const { width, height } = Dimensions.get("window");

// ✅ Map must match the lowercase filenames in assets/ folder exactly
const SOUND_MAP: Record<string, any> = {
  'azan_nasser_elktamy': require('../assets/azan_nasser_elktamy.mp3'),
  'azan_egypt': require('../assets/azan_egypt.mp3'),
  'azan_good': require('../assets/azan_good.mp3'),
  'azan_good_2': require('../assets/azan_good_2.mp3'),
  'azan_abdel_baset': require('../assets/azan_abdel_baset.mp3'),
};

const ARABIC_NAMES: Record<string, string> = {
  Fajr: "الفجر",
  Dhuhr: "الظهر",
  Asr: "العصر",
  Maghrib: "المغرب",
  Isha: "العشاء",
  Sunrise: "الشروق"
};

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [refreshing, setRefreshing] = useState(false);
  const [nextPrayer, setNextPrayer] = useState<PrayerItem | null>(null);
  const [todayPrayers, setTodayPrayers] = useState<PrayerItem[]>([]);
  const [locationName, setLocationName] = useState("جاري التحديد...");
  const [locationModalVisible, setLocationModalVisible] = useState(false);

  // Audio State
  const [soundModalVisible, setSoundModalVisible] = useState(false);
  const [soundName, setSoundName] = useState("الافتراضي");
  const [selectedSoundId, setSelectedSoundId] = useState("azan_nasser_elktamy");

  // ✅ FIX: Audio Player Logic without setTimeout
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [audioSource, setAudioSource] = useState<any>(null);

  // This hook creates a player. When 'audioSource' changes, 'player' updates.
  const player = useAudioPlayer(audioSource);

  // ✅ Auto-play when the player instance is ready
  useEffect(() => {
    if (player && previewId) {
      player.play();
    }
  }, [player, previewId]);

  const todayDate = new Date().toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' });

  useEffect(() => {
    checkAndroidBackgroundRestrictions();
    loadSettings();
    // ✅ FALSE = Fast Load (Use Cache/Last Known Location)
    handleSync(false); 
  }, []);

  const loadSettings = async () => {
    const prefId = await getSoundPreference();
    setSelectedSoundId(prefId);
    const soundObj = AZAN_SOUNDS.find(s => s.id === prefId);
    if (soundObj) setSoundName(soundObj.name);
  };

  // ✅ Updated to accept 'force' parameter
  const handleSync = async (force: boolean = false) => {
    setRefreshing(true);
    try {
      // ✅ Pass forceGps to the scheduler
      const result = await refreshPrayerSchedule({ daysAhead: 5, forceGps: force });
      setNextPrayer(result.nextPrayer);
      setTodayPrayers(result.todayPrayers);
      if (result.locationName) setLocationName(result.locationName);
    } catch (e) {
      // quiet fail
    } finally {
      setRefreshing(false);
    }
  };

  const testAdhan = async () => {
    await scheduleTestAzan(5);
    alert("تم جدولة تجربة الآذان خلال 5 ثواني");
  };

  const selectCity = async (city: City) => {
    setLocationModalVisible(false);
    setLocationName(city.name);
    await saveLocationPreference('manual', { lat: city.lat, lng: city.lng, name: city.name });
    // ✅ FORCE update when changing city manually
    handleSync(true); 
  };

  const selectAuto = async () => {
    setLocationModalVisible(false);
    setLocationName("جاري تحديد الموقع...");
    await saveLocationPreference('auto');
    // ✅ FORCE update when switching to Auto
    handleSync(true); 
  };

  const handleSoundSelect = async (sound: AzanSound) => {
    // Stop preview if running
    if (player.playing) {
      player.pause();
    }
    setPreviewId(null);
    setAudioSource(null);

    setSelectedSoundId(sound.id);
    setSoundName(sound.name);
    await saveSoundPreference(sound.id);
    setSoundModalVisible(false);
    
    // ✅ No need to force GPS, just reschedule alarms
    handleSync(false); 
  };

  // ✅ Safe Play Function
  const playPreview = (id: string) => {
    const asset = SOUND_MAP[id];
    if (!asset) return alert("الملف الصوتي غير موجود في الأصول");

    if (previewId === id && player.playing) {
      // Toggle Off
      player.pause();
      setPreviewId(null);
      setAudioSource(null);
    } else {
      // Change Source (The useEffect above will catch this and play)
      setAudioSource(asset);
      setPreviewId(id);
    }
  };

  return (
    <View style={styles.mainContainer}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      {/* HERO SECTION */}
      <ImageBackground
        source={require("../assets/mosque.jpg")}
        style={[styles.headerBg, { paddingTop: insets.top + 10 }]}
        resizeMode="cover"
      >
        <LinearGradient
          colors={['rgba(0,0,0,0.4)', 'transparent', 'rgba(0,0,0,0.6)']}
          style={StyleSheet.absoluteFill}
        />

        {/* Top Bar */}
        <View style={styles.topBar}>
          {/* Location Button (Left) */}
          <TouchableOpacity
            style={styles.locationBtn}
            onPress={() => setLocationModalVisible(true)}
          >
            <Ionicons name="location-sharp" size={16} color="#FFD700" style={{ marginRight: 6 }} />
            <Text style={styles.locationText}>{locationName}</Text>
            <Ionicons name="chevron-down" size={14} color="#ccc" style={{ marginLeft: 6 }} />
          </TouchableOpacity>

          {/* Date (Right) */}
          <Text style={styles.dateText}>{todayDate}</Text>
        </View>

        <View style={styles.countdownWrapper}>
          <NextPrayerCountdown
            nextPrayerTime={nextPrayer?.time || null}
            nextPrayerName={nextPrayer?.name || null}
          />
        </View>
      </ImageBackground>

      {/* PRAYER LIST & CONTROLS */}
      <View style={styles.sheetContainer}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
          refreshControl={
            // ✅ FORCE update on Pull-to-Refresh
            <RefreshControl refreshing={refreshing} onRefresh={() => handleSync(true)} tintColor="#1a2a6c" />
          }
        >
          <View style={styles.handleBar} />

          {todayPrayers.map((p, i) => {
            const isNext = p.name === nextPrayer?.name;
            const arabicName = ARABIC_NAMES[p.name] || p.name;

            return (
              <View
                key={`${p.name}-${i}`}
                style={[styles.prayerRow, isNext && styles.activeRow]}
              >
                <Text style={[styles.prayerTime, isNext && styles.activeText]}>
                  {p.time.toLocaleTimeString('en-US', { hour: "2-digit", minute: "2-digit" })}
                </Text>

                <View style={styles.rowRight}>
                  <Text style={[styles.prayerName, isNext && styles.activeText]}>
                    {arabicName}
                  </Text>
                  <Ionicons
                    name={isNext ? "time" : "ellipse-outline"}
                    size={18}
                    color={isNext ? "#fff" : "#8E8E93"}
                  />
                </View>
              </View>
            );
          })}

          <View style={styles.controlsRow}>

            <TouchableOpacity style={styles.controlBtn} onPress={testAdhan}>
              <LinearGradient
                colors={['#1a2a6c', '#2a4a8c']}
                style={styles.controlBtnGradient}
              >
                <Ionicons name="play-circle" size={20} color="#FFD700" />
                <Text style={styles.controlBtnText}>تجربة الآذان (5ث)</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity style={styles.controlBtn} onPress={() => setSoundModalVisible(true)}>
              <LinearGradient
                colors={['#1a2a6c', '#2a4a8c']}
                style={styles.controlBtnGradient}
              >
                <Ionicons name="volume-high" size={20} color="#FFD700" />
                <Text style={styles.controlBtnText}>تغيير الآذان</Text>
              </LinearGradient>
            </TouchableOpacity>

          </View>

        </ScrollView>
      </View>

      {/* LOCATION SELECTION MODAL */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={locationModalVisible}
        onRequestClose={() => setLocationModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>تغيير الموقع</Text>
              <TouchableOpacity onPress={() => setLocationModalVisible(false)}>
                <Ionicons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.autoLocationBtn} onPress={selectAuto}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Ionicons name="navigate-circle" size={28} color="#007AFF" />
                <Text style={styles.autoText}>تحديد تلقائي (GPS)</Text>
              </View>
              <Ionicons name="chevron-back" size={20} color="#ccc" />
            </TouchableOpacity>

            <Text style={styles.sectionTitle}>محافظات مصر</Text>

            <FlatList
              data={EGYPT_CITIES}
              keyExtractor={(item) => item.nameEn}
              renderItem={({ item }) => (
                <TouchableOpacity style={styles.cityItem} onPress={() => selectCity(item)}>
                  <Text style={styles.cityName}>{item.name}</Text>
                  <Text style={styles.cityNameEn}>{item.nameEn}</Text>
                </TouchableOpacity>
              )}
              style={{ maxHeight: height * 0.4 }}
            />
          </View>
        </View>
      </Modal>

      {/* SOUND SELECTION MODAL */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={soundModalVisible}
        onRequestClose={() => setSoundModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '60%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>صوت الآذان</Text>
              <TouchableOpacity onPress={() => setSoundModalVisible(false)}>
                <Ionicons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>

            <FlatList
              data={AZAN_SOUNDS}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <View style={[styles.cityItem, item.id === selectedSoundId && { backgroundColor: '#F0F8FF' }]}>

                  <TouchableOpacity
                    style={{ flex: 1, flexDirection: 'row-reverse', alignItems: 'center', gap: 10 }}
                    onPress={() => handleSoundSelect(item)}
                  >
                    {item.id === selectedSoundId && <Ionicons name="checkmark-circle" size={24} color="#007AFF" />}
                    <Text style={[styles.cityName, item.id === selectedSoundId && { color: '#007AFF', fontWeight: 'bold' }]}>
                      {item.name}
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity onPress={() => playPreview(item.id)} style={{ padding: 8 }}>
                    <Ionicons
                      name={previewId === item.id ? "stop-circle" : "play-circle"}
                      size={32}
                      color={previewId === item.id ? "#FF3B30" : "#1a2a6c"}
                    />
                  </TouchableOpacity>

                </View>
              )}
            />
          </View>
        </View>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: "#000",
  },
  headerBg: {
    width: width,
    height: height * 0.40,
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  dateText: {
    color: "#fff",
    fontSize: 14,
    opacity: 0.9,
    fontWeight: "600",
  },
  locationBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(0,0,0,0.4)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)'
  },
  locationText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  countdownWrapper: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 60,
  },
  sheetContainer: {
    flex: 1,
    marginTop: -30,
    backgroundColor: "#F7F9FC",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
  },
  scrollContent: {
    padding: 20,
    paddingTop: 10,
    paddingBottom: 40,
  },
  handleBar: {
    width: 40,
    height: 4,
    backgroundColor: "#D1D1D6",
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 20,
    marginTop: 10,
  },
  prayerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 10,
    backgroundColor: "#fff",
    borderRadius: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  activeRow: {
    backgroundColor: "#1a2a6c",
    transform: [{ scale: 1.02 }],
    shadowColor: "#1a2a6c",
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },
  rowRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  prayerName: {
    fontSize: 18,
    color: "#333",
    fontWeight: "600",
  },
  prayerTime: {
    fontSize: 18,
    color: "#333",
    fontWeight: "700",
  },
  activeText: {
    color: "#FFD700",
  },

  // CONTROLS
  controlsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 15,
    marginTop: 20,
    paddingHorizontal: 10,
  },
  controlBtn: {
    flex: 1,
    borderRadius: 25,
    overflow: 'hidden',
    shadowColor: "#1a2a6c",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  controlBtnGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    gap: 8,
  },
  controlBtnText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "bold",
  },

  // MODAL STYLES
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    padding: 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  autoLocationBtn: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#F0F8FF',
    padding: 15,
    borderRadius: 12,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#007AFF',
  },
  autoText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#007AFF',
  },
  sectionTitle: {
    fontSize: 14,
    color: '#888',
    marginBottom: 10,
    textAlign: 'right'
  },
  cityItem: {
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  cityName: {
    fontSize: 18,
    color: '#333',
  },
  cityNameEn: {
    fontSize: 14,
    color: '#999',
  }
});