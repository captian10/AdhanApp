import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface Props {
  nextPrayerTime: Date | null;
  nextPrayerName: string | null;
}

const ARABIC_NAMES: Record<string, string> = {
  Fajr: "الفجر",
  Dhuhr: "الظهر",
  Asr: "العصر",
  Maghrib: "المغرب",
  Isha: "العشاء",
  Sunrise: "الشروق"
};

export default function NextPrayerCountdown({ nextPrayerTime, nextPrayerName }: Props) {
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    if (!nextPrayerTime) return;

    const interval = setInterval(() => {
      const now = new Date();
      const diff = nextPrayerTime.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeLeft('الآن');
        return;
      }
      
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      const h = hours < 10 ? `0${hours}` : hours;
      const m = minutes < 10 ? `0${minutes}` : minutes;
      const s = seconds < 10 ? `0${seconds}` : seconds;

      // Keep numbers Left-to-Right for the timer (Standard format)
      setTimeLeft(`-${h}:${m}:${s}`);
    }, 1000);

    return () => clearInterval(interval);
  }, [nextPrayerTime]);

  if (!nextPrayerTime) return null;

  const arabicName = nextPrayerName ? (ARABIC_NAMES[nextPrayerName] || nextPrayerName) : "";

  return (
    <View style={styles.container}>
      <Text style={styles.label}>الصلاة التالية: {arabicName}</Text>
      <Text style={styles.timer}>{timeLeft}</Text>
      <Text style={styles.subTime}>
        {nextPrayerTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
  },
  label: { 
    color: '#FFD700', 
    fontSize: 18, // Slightly bigger for Arabic
    fontWeight: '700',
    marginBottom: 0,
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  timer: { 
    color: '#FFFFFF', 
    fontSize: 56, 
    fontWeight: '200', 
    fontVariant: ['tabular-nums'], 
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 4 },
    textShadowRadius: 10,
    lineHeight: 70, 
  },
  subTime: { 
    color: 'rgba(255,255,255,0.9)', 
    fontSize: 20,
    fontWeight: "500",
    marginTop: 5,
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
});